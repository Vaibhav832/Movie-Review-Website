
<hr>
<footer>
	<p class="text-center"><a href="https://www.linkedin.com/in/vaibhav-srivastava-8d3m2y/" target="_blank">&copy; Vaibhav Srivastava </a><a>&</a><a href="https://www.linkedin.com/in/shivani-tiwari-74a403211/" target="_blank"> Shivani Tiwari </a></p>
</footer>
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</body>
</html>